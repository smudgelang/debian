#ifndef __SMEAR_VERSION_H__
#define __SMEAR_VERSION_H__

#define SMEAR_VERSION "0.1"
#define SMEAR_VERSION_MAJOR 0
#define SMEAR_VERSION_MINOR 1

#endif
